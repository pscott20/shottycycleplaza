//bxSlider used on Store page. The page features multiple bxsliders
$(document).ready(function(){
    $('#slider1').bxSlider(
      caption = true, //Adds captions
      maxSlide = 1 //Limits the number of slides viewed to 1
    );
  });
  $(document).ready(function(){
    $('#slider2').bxSlider( 
      caption = true,
      maxSlide = 1
    );
  });
  $(document).ready(function(){
    $('#slider3').bxSlider(
      caption = true,
      maxSlide = 1
    );
  });